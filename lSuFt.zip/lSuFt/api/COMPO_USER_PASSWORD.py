import os
try:import asyncio, aiohttp, MedoSigner
except:os.system("pip install asyncio aiohttp pycryptodome MedoSigner")
import asyncio, aiohttp, os, urllib.parse, re, random, binascii, uuid, time
from MedoSigner import Argus, Gorgon, Ladon, md5
P='\x1b[1;97m'
B='\x1b[1;94m'
O='\x1b[1;96m'
Z='\x1b[1;30m'
X='\x1b[1;33m'
F='\x1b[2;32m'
Z='\x1b[1;31m'
L='\x1b[1;95m'
C='\x1b[2;35m'
A='\x1b[2;39m'
P='\x1b[38;5;231m'
J='\x1b[38;5;208m'
J1='\x1b[38;5;202m'
J2='\x1b[38;5;203m'
J21='\x1b[38;5;204m'
J22='\x1b[38;5;209m'
F1='\x1b[38;5;76m'
C1='\x1b[38;5;120m'
P1='\x1b[38;5;150m'
P2='\x1b[38;5;190m'
a1 = '\x1b[1;35m'  # بنفسجي
a2 = '\x1b[1;34m'  # أزرق
a3 = '\x1b[1;32m'  # أخضر
a4 = '\x1b[1;33m'  # أصفر
a5 = '\x1b[1;36m'  # سماوي
RED = '\x1b[1;31m'  # أحمر
ORANGE = '\x1b[38;5;208m'  # برتقالي
W = '\x1b[0m'  # ابيض
def clear():
    __import__("os").system("cls" if __import__("os").name == "nt" else "clear")
    rndm= __import__("random").choice([a1,a2,a3,a4,a5])
    print(f"{a2}╭───────────────────────────────────────────────────────────╮")
    print(f"""{a2}│\t  {rndm}██████╗░███████╗███╗░░░███   ╗░█████╗░ \t    
{a2}│{rndm}\t ██╔══██╗██╔════╝████╗░████  ║██╔══██╗\t
{a2}│{rndm}\t ██║░░██║█████╗░░██╔████╔██ ║██║░░██║   \t
{a2}│{rndm}\t ██║░░██║██╔══╝░░██║╚██╔╝██  ║██║░░██║  \t
{a2}│{rndm}\t ██████╔╝███████╗██║░╚═╝░██ ║╚█████╔╝   \t
{a2}│{rndm}\t ╚═════╝░╚══════╝╚═╝░░░░░╚═    ╝░╚════╝░   \t""")
    print(f"{a2}┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫")
    print(f"{a2}┃{a3} 🫧  {a4}Tool:Compo{a2} ┃{a4} Dev: {a3}⏤͟͞ 𝗗𝗘𝗠𝗢🇮🇶  {a2} ┃{a4} Tle: {a3}@S_44_F{a2} ┃Ch: {a3}@D_EM0{a2} ┃")
    print(f"{a5}╰───────────────────────────────────────────────────────────╮{W}")    
clear()
save_format = ""  
print(f"{a2}【 {a3}●{a2} 】{a3}Choose Scraping Mode:")
print(f"{a2}【 {a5}1{a2} 】{a3}Usernames only (without ':')")
print(f"{a2}【 {a5}2{a2} 】{a3}Usernames with passwords (user:pass)")
print(f"{a5}╰──────────────────────────────────────────────────────╯{W}")
mode = input(f"{a2}【 {a5}●{a2} 】{a3}Select Mode (1/2): {W}").strip()
clear()
if mode == "1":
    psw = []
    save_format = "username_only"
elif mode == "2":
    psw_example = 'user,user1,12345678,123456,user123'
    print(f"\n{a2}【 {a3}●{a2} 】{a3}Password example: {a5}{psw_example}{W}")
    psw_input = input(f"{a2}【 {a5}●{a2} 】{a3}Enter passwords (comma separated): {W}")
    psw = [p.strip() for p in psw_input.split(',') if p.strip()]
    save_format = "with_passwords"
else:
    exit(f"{RED}Invalid mode selection!{W}")

clear()
a = 0
users = set()
user_queue = asyncio.Queue()
lock = asyncio.Lock()
asian_countries=[("SA","Saudi Arabia","السعودية","🇸🇦"),("AE","United Arab Emirates","الإمارات","🇦🇪"),("IQ","Iraq","العراق","🇮🇶"),("SY","Syria","سوريا","🇸🇾"),("JO","Jordan","الأردن","🇯🇴"),("LB","Lebanon","لبنان","🇱🇧"),("KW","Kuwait","الكويت","🇰🇼"),("QA","Qatar","قطر","🇶🇦"),("OM","Oman","عُمان","🇴🇲"),("BH","Bahrain","البحرين","🇧🇭"),("YE","Yemen","اليمن","🇾🇪"),("TR","Turkey","تركيا","🇹🇷"),("IR","Iran","إيران","🇮🇷"),("AF","Afghanistan","أفغانستان","🇦🇫"),("PK","Pakistan","باكستان","🇵🇰"),("IN","India","الهند","🇮🇳"),("BD","Bangladesh","بنغلاديش","🇧🇩"),("NP","Nepal","نيبال","🇳🇵"),("LK","Sri Lanka","سريلانكا","🇱🇰"),("MV","Maldives","المالديف","🇲🇻"),("CN","China","الصين","🇨🇳"),("JP","Japan","اليابان","🇯🇵"),("KR","South Korea","كوريا الجنوبية","🇰🇷"),("KP","North Korea","كوريا الشمالية","🇰🇵"),("MN","Mongolia","منغوليا","🇲🇳"),("KZ","Kazakhstan","كازاخستان","🇰🇿"),("UZ","Uzbekistan","أوزبكستان","🇺🇿"),("TM","Turkmenistan","تركمانستان","🇹🇲"),("KG","Kyrgyzstan","قرغيزستان","🇰🇬"),("TJ","Tajikistan","طاجيكستان","🇹🇯"),("RU","Russia (Asian Part)","روسيا (الجزء الآسيوي)","🇷🇺"),("ID","Indonesia","إندونيسيا","🇮🇩"),("MY","Malaysia","ماليزيا","🇲🇾"),("SG","Singapore","سنغافورة","🇸🇬"),("TH","Thailand","تايلاند","🇹🇭"),("VN","Vietnam","فيتنام","🇻🇳"),("PH","Philippines","الفلبين","🇵🇭"),("MM","Myanmar","ميانمار","🇲🇲"),("KH","Cambodia","كمبوديا","🇰🇭"),("LA","Laos","لاوس","🇱🇦"),("BN","Brunei","بروناي","🇧🇳"),("TL","Timor-Leste","تيمور الشرقية","🇹🇱"),("GE","Georgia","جورجيا","🇬🇪"),("AM","Armenia","أرمينيا","🇦🇲"),("AZ","Azerbaijan","أذربيجان","🇦🇿"),("IL","Israel","إسرائيل","🇮🇱"),("PS","Palestine","فلسطين","🇵🇸")]
for i, (name_en, name_ar, flag, code) in enumerate(asian_countries, start=1):
    print(f"{a2}【{a3}{i}{a2}】{a3}{name_en} {a2}| {a5}{name_ar} {flag} {a2}| {a4}[{code}]{W}")
try:
    choice = int(input(f"{a2}【 {a5}●{a2} 】{a3}ENTER{W}: {a5}"))
    if 1 <= choice <= len(asian_countries):
        COUNTRY = asian_countries[choice - 1][0] 
    else:
        exit(f"{a2}【 {RED}●{a2} 】{RED}NUMBER NOT FOUND {W}")
except ValueError:
    exit(f"{a2}【 {RED}●{a2} 】{RED}WRONG NUMBER {W}")
clear()
print(f"{a2}【 {a3}●{a2} 】{a3}Example {a2}[{a3}0-10000 | 5000-15000{a2}] {W}")
range_input = input(f"{a2}【 {a5}●{a2} 】{a3}ENTER{W}: {a5}").strip()
try:
    min_followers, max_followers = map(int, range_input.split('-'))
except:
    print(f"{a2}【 {a3}●{a2} 】{a3}Example {a2}[{a3}0-10000 | 5000-15000{a2}] {W}")
    exit()

clear()


def Vals():
    return {"manifest_version_code": "330802","_rticket": str(round(random.uniform(1.2, 1.6) * 100000000) * -1) + "4632","app_language": "ar","app_type": "normal","iid": str(random.randint(1, 10 ** 19)),"channel": "googleplay","device_type": "RMX3511","language": "ar","host_abi": "arm64-v8a","locale": "ar","resolution": "1080*2236","openudid": str(binascii.hexlify(os.urandom(8)).decode()),"update_version_code": "330802","ac2": "lte","cdid": str(uuid.uuid4()),"sys_region": "IQ","os_api": "33","timezone_name": "Asia/Baghdad","dpi": "360","carrier_region": "IQ","ac": "4g","device_id": str(random.randint(1, 10 ** 19)),"os_version": "13","timezone_offset": "10800","version_code": "330802","app_name": "musically_go","ab_version": "33.8.2","version_name": "33.8.2","device_brand": "realme","op_region": "IQ","ssmix": "a","device_platform": "android","build_number": "33.8.2","region": "IQ","aid": "1340","ts": str(round(random.uniform(1.2, 1.6) * 100000000) * -1)}, {'User-Agent': 'com.zhiliaoapp.musically/2023001020 (Linux; U; Android 13; ar; RMX3511; Build/TP1A.220624.014; Cronet/TTNetVersion:06d6a583 2023-04-17 QuicVersion:d298137e 2023-02-13)'}

def sign(params, payload: str = None, sec_device_id: str = "", cookie: str or None = None,
         aid: int = 1233, license_id: int = 1611921764, sdk_version_str: str = "2.3.1.i18n",
         sdk_version: int = 2, platform: int = 19, unix: int = None):
    x_ss_stub = md5(payload.encode('utf-8')).hexdigest() if payload is not None else None
    if not unix:
        unix = int(time.time())
    return Gorgon(params, unix, payload, cookie).get_value() | {
        "x-ladon": Ladon.encrypt(unix, license_id, aid),"x-argus": Argus.get_sign(params, x_ss_stub, unix, platform=platform, aid=aid,license_id=license_id, sec_device_id=sec_device_id,sdk_version=sdk_version_str, sdk_version_int=sdk_version)}

def pas(username: str):
    if save_format == "username_only":
        return [username]  
    ussr = ''.join(re.findall(r'[a-zA-Z]', username))
    hh = []
    for ppsw in psw:
        ppsw = str(ppsw).strip()
        if not ppsw:
            continue   
        if ppsw == "user":
            password = username
        elif ppsw.startswith("user") and len(ppsw) > 4:
            suffix = ppsw[4:]
            password = ussr + suffix
        else:
            password = ppsw
            
        hh.append(f"{username}:{password}")
    return hh
def file(username):
    account = pas(username)
    with open(f"COMPO_{COUNTRY}_{save_format}.txt", "a", encoding="utf-8") as f:
        for line in account:
            f.write(line + "\n")
async def get_following(session, user_id):
    global users, a
    token = None
    while True:
        try:
            p, h = Vals()
            signed = sign(params=urllib.parse.urlencode(p), payload="", cookie="")
            h.update({'x-ss-req-ticket': signed['x-ss-req-ticket'],'x-argus': signed["x-argus"],'x-gorgon': signed["x-gorgon"],'x-khronos': signed["x-khronos"],'x-ladon': signed["x-ladon"]})
            base_url = f'https://api16-normal-c-alisg.tiktokv.com/lite/v2/relation/following/list/?user_id={user_id}&count=50&source_type=1&request_tag_from=h5&{urllib.parse.urlencode(p)}'
            if token:
                base_url += f"&page_token={urllib.parse.quote(token)}"
            async with session.get(base_url, headers=h) as response:
                data = await response.json()
            for user in data.get("followings", []):
                reg = user.get("region")
                fol = user.get("follower_count")
                username = user.get("unique_id")
                async with lock:
                    if username:
                        if reg in COUNTRY:
                         if min_followers < int(fol) < max_followers and username not in users:
                            a += 1
                            users.add(username)
                            print(f"{a2}【 {a5}{a}{a2} 】{a3}{username} {a2}| {a3}{fol} {a2}| {a3}{reg}{W}")
                            file(username)
            if not data.get("has_more"):
                break
            token = data.get("next_page_token")
            if not token:
                break
        except Exception:
            break
            
import random
def V12():
    language_sets = {'ar': ['ضصثقفغعهخحجشسيبلاتنمكطذءؤرىةوزظد','abcdefghijklmnopqrstuvwxyz'],'cyrillic': ['абвгдеёжзийклмнопрстуфхцчшщъыьэюя','abcdefghijklmnopqrstuvwxyz'],'th': ['กขฃคฅฆงจฉชซฌญฎฏฐฑฒณดตถทธนบปผฝพฟภมยรลวศษสหฬอฮ','abcdefghijklmnopqrstuvwxyz'],'ja': ['あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわをん','abcdefghijklmnopqrstuvwxyz'],'ko': ['가나다라마바사아자차카타파하','abcdefghijklmnopqrstuvwxyz'],'zh': ['的一是不了人我在有他这为之大来以个中上们','abcdefghijklmnopqrstuvwxyz'],'he': ['אבגדהוזחטיכלמנסעפצקרשתךףץןם','abcdefghijklmnopqrstuvwxyz'],'fa': ['پچژکگهمنوتآابپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی','abcdefghijklmnopqrstuvwxyz'],'fr': ['abcdefghijklmnopqrstuvwxyzéèêëàâîïôûùç','abcdefghijklmnopqrstuvwxyz'],'de': ['abcdefghijklmnopqrstuvwxyzäöüß','abcdefghijklmnopqrstuvwxyz'],'vi': ['abcdefghijklmnopqrstuvwxyzăâđêôơư','abcdefghijklmnopqrstuvwxyz'],'el': ['αβγδεζηθικλμνξοπρστυφχψω','abcdefghijklmnopqrstuvwxyz'],'hi': ['कखगघङचछजझञटठडढणतथदधनपफबभमयरलवशषसह','abcdefghijklmnopqrstuvwxyz'],'ta': ['அஆஇஈஉஊஎஏஐஒஓஔகஙசஜஞடணதநனபமயரலவழளறன','abcdefghijklmnopqrstuvwxyz'],'si': ['අආඇඈඉඊඋඌඍඎඏඐඑඒඓඔඕඖකඛගඝඞඟචඡජඣඤඥඦටඨඩඪණඬතථදධනඳපඵබභමඹයරලවශෂසහළෆ','abcdefghijklmnopqrstuvwxyz'],'my': ['ကခဂဃငစဆဇဈဉညတထဒဓနပဖဗဘမယရလဝသဟဠအ','abcdefghijklmnopqrstuvwxyz'],'default': ['abcdefghijklmnopqrstuvwxyz']}
    country_language_map = {'SA': 'ar', 'AE': 'ar', 'IQ': 'ar', 'SY': 'ar', 'JO': 'ar', 'LB': 'ar', 'KW': 'ar', 'QA': 'ar', 'OM': 'ar', 'BH': 'ar', 'YE': 'ar', 'PS': 'ar', 'RU': 'cyrillic', 'BY': 'cyrillic', 'UA': 'cyrillic', 'KZ': 'cyrillic', 'KG': 'cyrillic', 'TJ': 'cyrillic', 'TM': 'cyrillic', 'UZ': 'cyrillic', 'TH': 'th', 'JP': 'ja', 'KR': 'ko', 'CN': 'zh', 'IL': 'he', 'IR': 'fa', 'AF': 'fa', 'IN': 'hi', 'LK': 'si', 'MM': 'my', 'VN': 'vi', 'GR': 'el'}
    language = country_language_map.get(COUNTRY, 'default')
    kew = random.choice(language_sets.get(language, language_sets['default']))
    k = ''.join((random.choice(kew) for _ in range(random.randrange(2, 9))))
    return k
async def search(session):
    while True:
        try:
            username = V12()
            url = "https://search16-normal-c-alisg.tiktokv.com/aweme/v1/search/user/sug/?iid=" + str(
                random.randint(1, 10 ** 19)) + "&device_id=" + str(random.randint(1, 10 ** 19)) + "&ac=wifi&channel=googleplay&aid=1233&app_name=musical_ly&version_code=300102&version_name=30.1.2&device_platform=android&os=android&ab_version=30.1.2&ssmix=a&device_type=RMX3511&device_brand=realme&language=ar&os_api=33&os_version=13&openudid=" + str(
                binascii.hexlify(os.urandom(8)).decode()) + "&manifest_version_code=2023001020&resolution=1080*2236&dpi=360&update_version_code=2023001020&_rticket=" + str(
                round(random.uniform(1.2, 1.6) * 100000000) * -1) + "4632" + "&current_region=IQ&app_type=normal&sys_region=IQ&mcc_mnc=41805&timezone_name=Asia%2FBaghdad&carrier_region_v2=418&residence=IQ&app_language=ar&carrier_region=IQ&ac2=wifi&uoo=0&op_region=IQ&timezone_offset=10800&build_number=30.1.2&host_abi=arm64-v8a&locale=ar&region=IQ&content_language=gu%2C&ts=" + str(
                round(random.uniform(1.2, 1.6) * 100000000) * -1) + "&cdid=" + str(uuid.uuid4())
            payload = {
                'keyword': username,
                'count': "100",
                'source': "tt_ffp_add_friends",
                'mention_type': "0"
            }
            headers = {'Host': 'search16-normal-c-alisg.tiktokv.com',
                       'User-Agent': "com.zhiliaoapp.musically/2023105030 (Linux; U; Android 13; ar_IQ; RMX3511; Build/TP1A.220624.014; Cronet/TTNetVersion:2fdb62f9 2023-09-06 QuicVersion:bb24d47c 2023-07-19)"}
            headers.update(sign(url.split('?')[1], payload=urllib.parse.urlencode(payload)))
            async with session.post(url, data=payload, headers=headers) as response:
                data = await response.json()

            for item in data.get("sug_list", []):
                try:
                    extra = item.get("extra_info", {})
                    username = extra.get("sug_uniq_id")
                    user_id = extra.get("sug_user_id")
                    following = item.get("following_count", 0)

                    if username and user_id and re.fullmatch(r"[A-Za-z0-9_]+", username):
                        async with lock:
                            if username not in users:
                                users.add(username)
                                await user_queue.put(user_id)
                except:
                    continue
        except Exception:
            continue

async def worker(session):
    while True:
        try:
            user_id = await user_queue.get()
            await get_following(session, user_id)
            user_queue.task_done()
        except Exception:
            pass

async def main():
    async with aiohttp.ClientSession() as session:
        workers = [asyncio.create_task(worker(session)) for _ in range(50)]
        searches = [asyncio.create_task(search(session)) for _ in range(40)]

        await asyncio.gather(*workers, *searches)

def run():
    asyncio.run(main())